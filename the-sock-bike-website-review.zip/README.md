# The Sock Bike — website review copy

This is a static website for The Sock Bike, designed for free hosting on GitHub Pages.

## Preview

Open `index.html` in a modern browser. All files are included, and no web services or build tools are required.

## Files

- `index.html` — page content and structure
- `styles.css` — responsive visual design
- `script.js` — mobile navigation and automatic footer year
- `assets/the-sock-bike-logo.png` — your original uploaded logo, **copied unchanged**

## Before publishing

- Review all copy for accuracy.
- Confirm that `thesockbike@gmail.com` is the desired public contact email.
- Replace the outreach placeholders with real photos and updates when available. Obtain consent before publishing identifiable people.
- Donation links currently open an email inquiry. No payment processor is connected.
- This website makes no claim of registered charity or tax-deductible status.

## Publish later (only when approved)

Upload all files at the same paths to the `TheSockBike/thesockbike.github.io` public repository, then set GitHub Pages to deploy from `main` / `(root)`.
